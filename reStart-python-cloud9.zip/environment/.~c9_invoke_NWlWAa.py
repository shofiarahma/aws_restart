import array as arr

myArr = arr.array('i', [1,2,3])
print(type(myArr))

myCharArr = arr.array('u', ['a','b','c'])
print(myCharArr[0])
print(type(myCharArr))
# List
myFruitList = ["apple", "banana", "cherry"]
print('\nmyFruitList')
print(type(myFruitList))
print( )
print(myFruitList[0])
print(myFruitList[1])
print(myFruitList[2])
# Changing
myFruitList[0] = 