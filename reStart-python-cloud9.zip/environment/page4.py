import array as arr

myArr = arr.array('i', [1,2,3])
print(type(myArr))

myCharArr = arr.array('u', ['a','b','c'])
print(myCharArr[0])
print(type(myCharArr))
# List
myFruitList = ["apple", "banana", "cherry"]
print('\nmyFruitList')
print(type(myFruitList))
print( )
print(myFruitList[0])
print(myFruitList[1])
print(myFruitList[2])
# Changing
myFruitList[0] = "orange"
print(myFruitList[0])
print(myFruitList)
print(myFruitList[0])
print(myFruitList[-1])
print(myFruitList)

# 2d List
print( )
group = [
    ["carlos", "charles", "max"],
    ["lewis","george"]
 ]
    
print (group[0][0])
print (group[1][1])
print ( )

# Tuple
myFinalAnswerTuple = ("apple", "banana", "pineapple")
print(myFinalAnswerTuple)
print(type(myFinalAnswerTuple))
print(myFinalAnswerTuple[0])
print(myFinalAnswerTuple[1])
print(myFinalAnswerTuple[2])

myFinalAnswerTuple = ("grape", "mango", "pineapple")
print(type(myFinalAnswerTuple))
print(myFinalAnswerTuple[0])
print(myFinalAnswerTuple[1])
print(myFinalAnswerTuple[2])

# Dictionary
myFavoriteFruitDictionary = {
  "Akua" : "apple",
  "Saanvi" : "banana",
  "Paulo" : "pineapple"
}
print(myFavoriteFruitDictionary)
print(type(myFavoriteFruitDictionary))
print(myFavoriteFruitDictionary["Akua"])
print(myFavoriteFruitDictionary["Saanvi"])
print(myFavoriteFruitDictionary["Paulo"])
print(type(myFavoriteFruitDictionary))

# Set
print("\nSet")
mySet = {1,2,3}
print(mySet)